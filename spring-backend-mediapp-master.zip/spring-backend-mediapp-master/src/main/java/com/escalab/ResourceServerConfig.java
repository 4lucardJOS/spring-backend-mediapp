package com.escalab;

public class ResourceServerConfig {

}
