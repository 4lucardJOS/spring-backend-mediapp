package com.escalab;

public class AuthException {

}
