package com.escalab.model;

public class Examen {

}
