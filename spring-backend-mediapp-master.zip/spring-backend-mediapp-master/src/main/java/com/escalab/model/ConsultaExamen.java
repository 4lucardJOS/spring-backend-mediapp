package com.escalab.model;

public class ConsultaExamen {

}
