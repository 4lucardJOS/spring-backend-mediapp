package com.escalab.model;

public class DetalleConsulta {

}
