package com.escalab.model;

public class ResetToken {

}
