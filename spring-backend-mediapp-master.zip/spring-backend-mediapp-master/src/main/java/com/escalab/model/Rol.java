package com.escalab.model;

public class Rol {

}
