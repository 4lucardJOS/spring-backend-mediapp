package com.escalab.model;

public class Archivo {

}
