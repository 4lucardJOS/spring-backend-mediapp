package com.escalab;

public class AuthorizationServerConfig {

}
