package com.escalab.exception;

public class ResponseExceptionHandler {

}
