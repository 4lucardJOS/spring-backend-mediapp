package com.escalab.exception;

public class ModeloNotFoundException {

}
