package com.escalab;

public class SwaggerConfig {

}
