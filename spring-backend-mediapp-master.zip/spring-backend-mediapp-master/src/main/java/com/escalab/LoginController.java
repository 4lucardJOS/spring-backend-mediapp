package com.escalab;

public class LoginController {

}
