package com.escalab.dto;

public class FiltroConsultaDTO {

}
