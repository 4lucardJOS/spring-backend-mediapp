package com.escalab.dto;

public class ConsultaDTO {

}
