package com.escalab.dto;

public class ConsultaResumenDTO {

}
