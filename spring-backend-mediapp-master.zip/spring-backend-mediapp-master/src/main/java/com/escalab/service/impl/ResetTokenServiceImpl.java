package com.escalab.service.impl;

public class ResetTokenServiceImpl {

}
