package com.escalab.service;

public interface IPacienteService {

}
