package com.escalab.service.impl;

public class UsuarioServiceImpl {

}
