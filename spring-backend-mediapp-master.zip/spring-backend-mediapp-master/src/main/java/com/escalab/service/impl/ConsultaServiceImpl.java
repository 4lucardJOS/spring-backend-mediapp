package com.escalab.service.impl;

public class ConsultaServiceImpl {

}
