package com.escalab.service.impl;

public class ArchivoServiceImpl {

}
