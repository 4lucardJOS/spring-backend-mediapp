package com.escalab.service.impl;

public class LoginServiceImpl {

}
