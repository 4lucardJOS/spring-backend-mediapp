package com.escalab.service;

public interface IArchivoService {

}
