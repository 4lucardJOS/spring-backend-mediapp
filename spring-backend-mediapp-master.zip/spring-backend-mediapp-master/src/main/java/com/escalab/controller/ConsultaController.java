package com.escalab.controller;

public class ConsultaController {

	
}
