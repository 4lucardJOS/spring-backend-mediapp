package com.escalab.controller;

public class MedicoController {

}
