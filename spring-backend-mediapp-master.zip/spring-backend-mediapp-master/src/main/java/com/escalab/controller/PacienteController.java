package com.escalab.controller;

public class PacienteController {

}
