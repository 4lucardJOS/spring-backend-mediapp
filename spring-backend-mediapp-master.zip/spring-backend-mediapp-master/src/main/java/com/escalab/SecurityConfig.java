package com.escalab;

public class SecurityConfig {

}
