package com.escalab.util;

public class CORS {

}
