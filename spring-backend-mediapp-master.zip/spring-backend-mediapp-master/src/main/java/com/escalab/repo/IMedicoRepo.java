package com.escalab.repo;

public interface IMedicoRepo {

}
