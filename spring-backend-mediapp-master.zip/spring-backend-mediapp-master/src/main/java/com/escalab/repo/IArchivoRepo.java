package com.escalab.repo;

public interface IArchivoRepo {

}
