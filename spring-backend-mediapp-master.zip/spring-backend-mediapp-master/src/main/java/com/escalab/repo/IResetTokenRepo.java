package com.escalab.repo;

public interface IResetTokenRepo {

}
