package com.escalab.repo;

public interface IConsultaRepo {

}
