package com.escalab.repo;

public interface ILoginRepo {

}
