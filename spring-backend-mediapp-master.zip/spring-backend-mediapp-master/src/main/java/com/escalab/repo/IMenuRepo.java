package com.escalab.repo;

public interface IMenuRepo {

}
