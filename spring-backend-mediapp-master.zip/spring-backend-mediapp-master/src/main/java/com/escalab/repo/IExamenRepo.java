package com.escalab.repo;

public interface IExamenRepo {

}
